type Stack []${PARAM_TYPE}

func (s *Stack) pop() (${PARAM_TYPE}, bool) {
	if s.isEmpty() {
		return "", false
	}
	value := (*s)[len(*s)-1]
	*s = (*s)[:len(*s)-1]
	return value, true
}
func (s *Stack) push(str ${PARAM_TYPE}) {
	*s = append(*s, str)
}
func (s *Stack) isEmpty() bool {
	return len(*s) == 0
}
#[[$END$]]#
